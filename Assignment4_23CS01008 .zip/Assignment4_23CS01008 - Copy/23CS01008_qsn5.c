#include <stdio.h>
#include <math.h>
int main()
{
    int num;
    printf("Enter a number :");
    scanf("%d",&num);
    if( num > 999 || num < 100)
    {
        printf("Incorrect input");
    }
    else 
    {
        int cube = pow(num/100,3) + pow(num%10,3) + pow((num%100)/10,3);
        if( cube == num)
            printf("Armstrong number");
        else
            printf("Not an Armstrong number");
    }
    return 0;
}