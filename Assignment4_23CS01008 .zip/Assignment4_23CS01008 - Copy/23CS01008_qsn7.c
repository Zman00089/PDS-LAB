#include <stdio.h>
int main()
{
    double cost;
    int age;
    printf("Enter age :");
    scanf("%d",&age);
    if( age < 5)
    {
        printf("Free ticket");
    }
    else if( age <=12 )
        printf("Ticket cost : Rs.20");
    else if( age<=59 )
        printf("Ticket cost : Rs.50");
    else
    {
        cost = 0.8 * 50;
        printf("Ticket cost : Rs.%.2f",cost);
    }
    return 0;
}