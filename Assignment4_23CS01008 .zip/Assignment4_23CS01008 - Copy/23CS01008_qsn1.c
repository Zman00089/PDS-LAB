#include <stdio.h>
#include <math.h>
int main()
{
    int x;
    printf("Enter a number :");
    scanf("%d",&x);
    int rem = abs(x) % 2;
    switch( rem )
    {
        case 0:
        printf("Even Number");
        break;

        case 1:
        printf("Odd Number");

    }
    return 0;
}