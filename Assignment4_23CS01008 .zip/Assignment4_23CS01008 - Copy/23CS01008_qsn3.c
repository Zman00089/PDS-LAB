#include <stdio.h>
#include <math.h>
int main()
{
    double interest;
    int bal, credit;
    printf("Enter balance :");
    scanf("%d",&bal);
    printf("Enter credit score :");
    scanf("%d",&credit);
    if( credit > 600)
    {
        interest = 0.15 * 600 ;
        if( credit < 750)
            interest += 0.12 * (credit-600) ;
        else
            interest += 0.12 * 150 + 0.1 * (credit - 750);
    }
    else
        interest = 0.15 * credit;
    printf("Interest : %f",interest);

    return 0;
}