#include <stdio.h>
int main()
{
    int x,y,n;
    printf("Enter two numbers :");
    scanf("%d%d",&x,&y);
    printf("\n1:Addition\n2:Subtraction\n3:Division\n4:Multiplication\nEnter according to above :");
    scanf("%d",&n);
    switch( n )
    {
        case 1:
        printf("%d",x+y);
        break;

        case 2:
        printf("%d",x-y);
        break;

        case 3:
        printf("%f",x/(double)y);
        break;

        case 4:
        printf("%d",x*y);
        break;

        default:
        printf("Incorrect input");
    }
    return 0;
}