#include <stdio.h>
int main()
{
    int size;
    printf("Enter size of triangle :");
    scanf("%d",&size);
    
    for(int i = 0; i < size ;i++)
    {    
        //print appropriate spaces
        
        for( int j = 0;j < size-i-1; j++)
            printf(" ");

        //print the stars
        
        for(int k=0 ; k < i+1 ;k++)
            printf("* ");

        //go into next line
        
        printf("\n");
    }

    return 0;
}