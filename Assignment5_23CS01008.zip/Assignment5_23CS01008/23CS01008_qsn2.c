#include<stdio.h>

int main()
{
    int dividend,divisor,quotient=0,rem=0;
    printf("Enter the dividend and the divisor: ");
    scanf(" %d%d",&dividend,&divisor);
    
    for(int i = 0 ; i < divisor ; i++ )
    {
        if(dividend == 0)
        {
            rem = i;
            break;
        }
        dividend--;

        if(i == divisor-1)
        {
            quotient++;
            i =- 1;
        }
    }
    
    printf("\nQuotient = %d\nRemainder = %d",quotient,rem);

    // while (1)
    // {
    //     if (divisor == 0)
    //         break;
    //     if (dividend >= divisor)
    //     {
    //         dividend -= divisor;
    //         quotient++;
    //     }
    //     else
    //     {
    //         rem = dividend;
    //         break;
    //     }
    // }
    // printf("\nQuotient = %d\nRemainder = %d", quotient, rem);

    return 0;
}