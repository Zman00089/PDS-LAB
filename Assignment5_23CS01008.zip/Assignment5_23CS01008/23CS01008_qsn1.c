#include <stdio.h>
int main()
{
    int num,nod,sum=0;
    printf("Enter a number :");
    scanf("%d",&num);
    //for(int temp = num; temp != 0; temp/=10)
    //   nod++;
    
    for( int i = 1;i<10;i++)
    {
        for(int temp = num; temp != 0; temp /= 10)
        {
            nod++;
            if( temp%10 == i )
            {
                sum += temp%10;
                break;
            }
            
        }

    }
    printf("Number of digits : %d\nSum of unique digits :%d",nod,sum);
    return 0;
}