#include <stdio.h>
int main()
{
    int num, sum = 0;
    char option;
    do
    {
        printf("Provide the number :");
        scanf("%d",&num);
    
        if(num&1 == 0)
            sum+=num;
        
        printf("Do you want to continue ?");
        scanf(" %c",&option);

    }while( option == 'y' || option == 'Y');
    
    printf("Sum :%d",sum);
    return 0;
}