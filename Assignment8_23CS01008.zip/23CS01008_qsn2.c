#include <stdio.h>
int r1,r2,c1,c2;
void print(int temp[],int r,int c)
{
    printf("\n");
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
            printf("%d\t",*((temp+i*c) + j));
        printf("\n");
    }
}
void multiply(int arr[r1][c1],int brr[r2][c2],int mul[r1][c2])
{
    for(int i=0 ; i<r1 ; i++)
    {
        for(int j=0;j<c2;j++)
        {
            mul[i][j] = 0;
            for(int k=0;k<c1;k++)
                mul[i][j] += arr[i][k]*brr[k][j];
        }
    }
}

int main()
{
    
    printf("Enter dimensions of first array :");
    scanf("%d%d",&r1,&c1);
    int arr[r1][c1];
    printf("Enter elements of first array :");
    for(int i=0 ; i<r1 ; i++)
    {
        for(int j=0; j<c1; j++)
            scanf("%d",&arr[i][j]);
    }
    printf("Enter dimensions of second array :");
    scanf("%d%d",&r2,&c2);
    int brr[r2][c2];
    printf("Enter elements of second array :");
    for(int i=0 ; i<r2 ; i++)
    {
        for(int j=0; j<c2; j++)
            scanf("%d",&brr[i][j]);
    }
    print(&arr[0][0],r1,c1);
    print(&brr[0][0],r2,c2);
    int mul[r1][c2];
    multiply(arr,brr,mul); 
    print(&mul[0][0],r1,c2);
}