#include<stdio.h>
void reverse(int *arr,int length)
{
    int *front = arr , *back = arr+length-1;
    while(back>front)
    {
        int temp = *front;
        *front = *back;
        *back = temp;
        back--;
        front++;
    }
}
void print(int *arr,int len)
{
    for(int i=0;i<len;i++)
        printf("%d\t",*(arr+i));
    printf("\n");
}
int main()
{
    int n;
    printf("Enter no. of elements :");
    scanf("%d",&n);
    int arr[n];
    printf("Enter elements :");
    for(int i=0;i<n;i++)
        scanf("%d",&arr[i]);
    print(arr,n);
    reverse(arr,n);
    print(arr,n);
    return 0;
}