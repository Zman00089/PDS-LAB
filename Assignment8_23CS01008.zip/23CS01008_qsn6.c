#include <stdio.h>

void concat(char *s1,char *s2,char *final,int l1,int l2)
{
    int pos=0;
    for(int i=0;i<l1;i++)
        final[pos++] = s1[i];
    for(int i=0;i<l2;i++)
        final[pos++] = s2[i];
}
int main()
{
    int l1,l2;
    printf("Enter length of first string:");
    scanf("%d",&l1);
    char str1[l1];
    printf("Enter string :");
    scanf("%s",&str1);
    printf("Enter length of second string:");
    scanf("%d",&l2);
    char str2[l2];
    printf("Enter string :");
    scanf("%s",&str2);
    char str_final[l1+l2];
    concat(str1,str2,str_final,l1,l2);
    printf("%s",str_final);
}