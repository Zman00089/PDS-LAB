#include <stdio.h>
#include <string.h>

char stack[100];
int top = -1;
char pop()
{
    char data = '\0';
    if(top == -1)
        printf("Stack empty !\n");
    else
        data = stack[top--];
    return data;
}

void push(char x)
{
    if(top == 99)
        printf("Stack full !\n");
    else
        stack[++top] = x;
}

void reverse(char *txt)
{
    int len = strlen(txt);
    for(int i=0;i<len;i++)
        push(txt[i]);
    for(int i=0;i<len;i++)
        txt[i] = pop();
}

int main()
{
    char text[100];
    printf("Enter a string :");
    gets(text);
    reverse(text);
    printf("Reversed string :\n%s",text);
    return 0;
}