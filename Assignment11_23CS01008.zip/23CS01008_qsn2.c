#include <stdio.h>
#include <string.h>

char stack[100];
int top = -1;
char pop()
{
    char data = '\0';
    if(top == -1)
        printf("Stack empty !\n");
    else
        data = stack[top--];
    return data;
}

void push(char x)
{
    if(top == 99)
        printf("Stack full !\n");
    else
        stack[++top] = x;
}

char peek()
{
    char data = '\0';
    if(top == -1)
        printf("Stack empty !\n");
    else
        data = stack[top];
    return data;
}

void reverse(char *arr,int length)
{
    char *front = arr , *back = arr+length-1;
    while(back>front)
    {
        char temp = *front;
        *front = *back;
        *back = temp;
        back--;
        front++;
    }
}

void duplicate_removal(char *text)
{
    top = -1;
    push(text[0]);
    for(int i=1;i<strlen(text);i++)
    {
        if(top == -1)
            push(text[i]);
        else
        {
            if(peek()!=text[i])
                push(text[i]);
            else
                pop();
        }
    }
}
int main()
{
    char text[100];
    printf("Enter a string :");
    gets(text);
    duplicate_removal(text);
    int len = top+1;
    char form[len];
    for(int i=0;i<len;i++)
        form[i] = pop();
    reverse(form,len);
    printf("Modified string :\n%s",form);
    return 0;
}